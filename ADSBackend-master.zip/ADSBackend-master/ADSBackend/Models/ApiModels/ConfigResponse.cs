﻿namespace ADSBackend.Models.ApiModels
{
    public class ConfigResponse
    {

    }
}

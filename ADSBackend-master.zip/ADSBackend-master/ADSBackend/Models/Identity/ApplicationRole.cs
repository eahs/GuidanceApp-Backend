﻿using Microsoft.AspNetCore.Identity;

namespace ADSBackend.Models.Identity
{
    public class ApplicationRole : IdentityRole<int>
    {

    }
}

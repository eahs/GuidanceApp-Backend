﻿using ADSBackend.Models.Identity;

namespace ADSBackend.Models.HomeViewModels
{
    public class HomeViewModel
    {
        public ApplicationUser User { get; set; }
    }
}

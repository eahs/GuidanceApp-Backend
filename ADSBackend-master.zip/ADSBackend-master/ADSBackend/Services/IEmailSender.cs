﻿using System.Threading.Tasks;

namespace ADSBackend.Services
{
    public interface IEmailSender
    {
        Task SendEmailAsync(string email, string subject, string message);
    }
}
